/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.vintage_project.controller;

import com.maven.vintage_project.model.Products;
import com.maven.vintage_project.service.ProductService;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONObject;

@Path("/product")
public class ProductController {

    private final ProductService productService = new ProductService();

    @GET
    @Path("/getProductById")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getProductById(@QueryParam("id") Integer id) {
        JSONObject result = productService.getProductById(id);
        return Response.status(result.getInt("statusCode"))
                       .entity(result.toString())
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }

    @GET
    @Path("/getAllProducts")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllProducts() {
        JSONObject result = productService.getAllProducts();
        return Response.status(result.getInt("statusCode"))
                       .entity(result.toString())
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }

    @POST
    @Path("/addProduct")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addProduct(String bodyString) {
        try {
            JSONObject body = new JSONObject(bodyString);

            Products newProduct = new Products();
            newProduct.setName(body.getString("name"));
            newProduct.setDescription(body.getString("description"));
            newProduct.setPrice(body.getLong("price"));
            newProduct.setStockQuanty(body.getInt("stockQuanty"));
            newProduct.setCategoryId(body.getInt("categoryId"));

            JSONObject result = productService.addProduct(newProduct);
            return Response.status(result.getInt("statusCode"))
                           .entity(result.toString())
                           .type(MediaType.APPLICATION_JSON)
                           .build();

        } catch (Exception e) {
            e.printStackTrace();
            JSONObject error = new JSONObject();
            error.put("status", "InvalidRequest");
            error.put("statusCode", 400);
            error.put("error", e.getMessage());
            return Response.status(400).entity(error.toString()).build();
        }
    }
}

