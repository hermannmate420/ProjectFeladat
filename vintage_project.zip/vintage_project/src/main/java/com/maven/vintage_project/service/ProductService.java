/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.vintage_project.service;

import com.maven.vintage_project.model.Products;
import java.util.List;
import org.json.JSONObject;
import org.json.JSONArray;

public class ProductService {

    public JSONObject getProductById(Integer id) {
        JSONObject response = new JSONObject();
        String status = "success";
        int statusCode = 200;

        try {
            Products product = Products.getProductById(id);

            if (product == null) {
                status = "ProductNotFound";
                statusCode = 404;
            } else {
                JSONObject productJson = new JSONObject();
                productJson.put("productId", product.getProductId());
                productJson.put("name", product.getName());
                productJson.put("description", product.getDescription());
                productJson.put("price", product.getPrice());
                productJson.put("stockQuanty", product.getStockQuanty());
                productJson.put("categoryName", product.getCategory().getName());
                productJson.put("createdAt", product.getCreatedAt());
                productJson.put("productPicture", product.getProductPicture());

                response.put("result", productJson);
            }

        } catch (Exception e) {
            e.printStackTrace();
            status = "InternalError";
            statusCode = 500;
        }

        response.put("status", status);
        response.put("statusCode", statusCode);
        return response;
    }

    // 🔜 Példa: később ezeket is hozzá tudod adni
    public JSONObject getAllProducts() {
        JSONObject response = new JSONObject();
        String status = "success";
        int statusCode = 200;

        try {
            List<Products> products = new Products().getAllProducts(); // ha ilyet csinálsz majd
            JSONArray resultArray = new JSONArray();

            for (Products p : products) {
                JSONObject obj = new JSONObject();
                obj.put("productId", p.getProductId());
                obj.put("name", p.getName());
                obj.put("description", p.getDescription());
                obj.put("price", p.getPrice());
                obj.put("stockQuanty", p.getStockQuanty());
                obj.put("categoryId", p.getCategoryId());
                obj.put("createdAt", p.getCreatedAt());
                obj.put("productPicture", p.getProductPicture());

                resultArray.put(obj);
            }

            response.put("result", resultArray);

        } catch (Exception e) {
            e.printStackTrace();
            status = "InternalError";
            statusCode = 500;
        }

        response.put("status", status);
        response.put("statusCode", statusCode);
        return response;
    }

    public JSONObject addProduct(Products product) {
        JSONObject response = new JSONObject();
        String status = "success";
        int statusCode = 200;

        try {
            boolean success = new Products().addProducts(product);
            if (!success) {
                status = "AddFailed";
                statusCode = 500;
            }

        } catch (Exception e) {
            e.printStackTrace();
            status = "InternalError";
            statusCode = 500;
        }

        response.put("status", status);
        response.put("statusCode", statusCode);
        return response;
    }
}
