/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.vintage_project.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "products")
@NamedQueries({
    @NamedQuery(name = "Products.findAll", query = "SELECT p FROM Products p"),
    @NamedQuery(name = "Products.findByProductId", query = "SELECT p FROM Products p WHERE p.productId = :productId")
})
public class Products implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "product_id")
    private Integer productId;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "name")
    private String name;

    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "description")
    private String description;

    @Basic(optional = false)
    @NotNull
    @Column(name = "price")
    private long price;

    @Basic(optional = false)
    @NotNull
    @Column(name = "stock_quanty")
    private int stockQuanty;

    @Basic(optional = false)
    @NotNull
    @Column(name = "category_id")
    private int categoryId;

    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @PersistenceUnit
    private static EntityManagerFactory emf;

    public static EntityManager getEntityManager() {
        if (emf == null) {
            emf = Persistence.createEntityManagerFactory("com.maven_vintage_project_war_1.0-SNAPSHOTPU");
        }
        return emf.createEntityManager();
    }

    public Products() {
    }

    public Products(Integer productId, String name, String description, long price, int stockQuanty, int categoryId) {
        this.productId = productId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.stockQuanty = stockQuanty;
        this.categoryId = categoryId;
    }

    // --- Statikus lekérdezések ---

    public static Products getProductById(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Products.class, id);
        } catch (Exception e) {
            System.err.println("Hiba getProductById során: " + e.getMessage());
            return null;
        } finally {
            em.close();
        }
    }

    public List<Products> getAllProducts() {
        EntityManager em = getEntityManager();
        try {
            TypedQuery<Products> query = em.createNamedQuery("Products.findAll", Products.class);
            return query.getResultList();
        } catch (Exception e) {
            System.err.println("Hiba getAllProducts során: " + e.getMessage());
            return new ArrayList<>();
        } finally {
            em.close();
        }
    }

    public Boolean addProducts(Products p) {
        EntityManager em = getEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(p);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            System.err.println("Hiba addProducts során: " + e.getMessage());
            return false;
        } finally {
            em.close();
        }
    }

    // --- Getterek & Setterek ---

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public int getStockQuanty() {
        return stockQuanty;
    }

    public void setStockQuanty(int stockQuanty) {
        this.stockQuanty = stockQuanty;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public int hashCode() {
        return (productId != null ? productId.hashCode() : 0);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Products)) return false;
        Products other = (Products) object;
        return this.productId != null && this.productId.equals(other.productId);
    }

    @Override
    public String toString() {
        return "Products[ productId=" + productId + " ]";
    }
}
